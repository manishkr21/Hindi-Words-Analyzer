from syllable import count_ngram


file_names = []
for i in range(0,22):
    file_names.append('../../data/hi/hi_{:02d}.txt'.format(i))

count_ngram(3,file_names, 'Ques3/syllable/trigram_syll.txt')
